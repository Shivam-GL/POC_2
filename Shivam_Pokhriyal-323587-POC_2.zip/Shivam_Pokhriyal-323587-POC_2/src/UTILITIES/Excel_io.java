package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Excel_io {
	File f;
	FileInputStream fis;
	XSSFWorkbook wb;
	static XSSFSheet sh;
	static int no_of_rows;
	public String email;
	public String pass;
	public String ev;
	
	public Excel_io() {
		try {
			this.f=new File("C:\\Users\\shivam.pokhriyal\\Documents\\Poc_2.xlsx");
			this.fis=new FileInputStream(f);
			this.wb=new XSSFWorkbook(fis);
			sh=wb.getSheet("Sheet1");
			no_of_rows=count_row();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	public int count_row() {
		return (sh.getLastRowNum()-sh.getFirstRowNum());	
	}
	
	public ArrayList<Excel_io> read_excel() {
		ArrayList<Excel_io> Users=new ArrayList<Excel_io>();
		
		for(int i=1;i<=no_of_rows;i++) {
			Excel_io user=new Excel_io();
				XSSFRow row=sh.getRow(i);
				XSSFCell cell=row.getCell(1);
				user.email=cell.getStringCellValue();
				cell=row.getCell(2);
				user.pass=cell.getStringCellValue();
				cell=row.getCell(3);
				user.ev=cell.getStringCellValue();
				Users.add(user);
			}
		return Users;
	}
	
}
