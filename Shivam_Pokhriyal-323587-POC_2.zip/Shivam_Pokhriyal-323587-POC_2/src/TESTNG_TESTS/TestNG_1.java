package TESTNG_TESTS;

import java.util.ArrayList;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Base_classes.Authentication_class;
import Base_classes.Create_log;
import Base_classes.Home_page;
import UTILITIES.Excel_io;


public class TestNG_1 {
	WebDriver dr;
	public Home_page homepage;
	public Authentication_class login;
	public ArrayList<Excel_io> Users;
	public Create_log logs;
	
	@BeforeClass
	public void launch() {	
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		this.dr=new ChromeDriver();
		dr.get("http://automationpractice.com/index.php");
		Excel_io excel=new Excel_io();
		System.out.println("reading excel");
		Users=excel.read_excel();
	}
	 @Test(priority=1)
	 public void verify_home_page_Title() {
		  homepage=new Home_page(dr);
		  logs=new Create_log();
		  String ar=homepage.getHomeTitle();
		  String er="My Store";
		  String result;
		  if(ar.equals(er)) {
			  result="pass";
		  }
		  else {
			  result="false";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(er, ar);
		  sa.assertAll();
		  String name="verify_home_title";
		  logs.writeLog(name, er, ar, result);
		 
		  System.out.println("Home page title verified");
		 
		  
	 }
	 @Test(priority=2)
	 public void verify_signin_text() {
		  homepage=new Home_page(dr);
		  String ar=homepage.getSigninText();
		  String er="Sign in";
		  String result;
		  if(ar.equals(er)) {
			  result="pass";
		  }
		  else {
			  result="false";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(er, ar);
		  sa.assertAll();
		  String name="verify_signin_text";
		  logs.writeLog(name, er, ar,result );
	 }
	 @Test(priority=3)
	 public void test_signin_click() {
		 homepage=new Home_page(dr);
		 homepage.clickSignin(); 
		 login=new Authentication_class(dr);
		 String ar=login.getLoginTitle();
		  String er="Login - My Store";
		  String result;
		  if(ar.equals(er)) {
			  result="pass";
		  }
		  else {
			  result="false";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(er, ar);
		  sa.assertAll();
		  String name="test_signin_click";
		  logs.writeLog(name, er, ar, result);
	 }
  }
