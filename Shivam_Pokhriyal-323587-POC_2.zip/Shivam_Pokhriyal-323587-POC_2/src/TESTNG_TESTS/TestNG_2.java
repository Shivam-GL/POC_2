package TESTNG_TESTS;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Base_classes.Account_page;
import Base_classes.Authentication_class;
import UTILITIES.Excel_io;

public class TestNG_2 extends TestNG_1 {
	Account_page account;


  @Test(priority=4,dataProvider="credentialsprovider")
  public void test_login(String u,String p,String Expected_val) {
	  login=new Authentication_class(dr);
	  
	  login.doLogin(u, p);
	  account=new Account_page(dr);
	  String ar=account.getProfile();
	  String er=Expected_val;
	  String result;
	  if(ar.equals(er)) {
		  result="pass";
	  }
	  else {
		  result="false";
	  }
	  
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(er, ar);
	  account.signout();
	  String name="test_login";
	  logs.writeLog(name, er, ar, result);
	  sa.assertAll();
	 
	 
	 
  }
  @DataProvider(name="credentialsprovider")
  public String[][] get_testdata(){
	  String[][] register_name = new String[Users.size()][3];
	  int i=0;
	 for(Excel_io user:Users) 
	 {
		 register_name[i][0]= user.email; 
		 register_name[i][1]= user.pass; 
		 register_name[i][2]= user.ev; 
		 i++;
	 }
	 
	  return register_name;
  }
}
