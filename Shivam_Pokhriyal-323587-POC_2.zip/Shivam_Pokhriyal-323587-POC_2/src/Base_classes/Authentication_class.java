package Base_classes;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Authentication_class {
	WebDriver dr;

	
	@FindBy(xpath="//input[@id=\"email\"]")
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"passwd\"]")
	WebElement pwd;
	
	@FindBy(xpath="//*[@id=\"SubmitLogin\"]")
	WebElement loginbtn;
	
	@FindBy(xpath="//*[@id=\"center_column\"]/div[1]/ol/li")
	WebElement error;
	
	public Authentication_class(WebDriver dr) {
		this.dr=dr;
		
		PageFactory.initElements(dr, this);
	}
	public void set_uname(String un) {
		email.clear();
		email.sendKeys(un);
		
	}
	public void set_pwd(String pword) {
		pwd.clear();
		pwd.sendKeys(pword);
		
	}
	public void clk_btn() {
		loginbtn.click();
		
	}
	
	public void doLogin(String u, String p) {
		this.set_uname(u);
		this.set_pwd(p);
		this.clk_btn();
	
	}
	
	public String getLoginTitle() {
		try {
		WebDriverWait wt=new WebDriverWait(dr,10);
		wt.until(ExpectedConditions.titleIs(dr.getTitle()));
		}
		catch(Exception e) {
			System.out.println("element not found ");
		}
		String av=dr.getTitle();
	
		return av;
		
	}
}
