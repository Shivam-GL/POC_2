package Base_classes;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Account_page {
	WebDriver dr;
	@FindBy(xpath="//a[@title=\"View my customer account\"]")
	WebElement profile;
	@FindBy(xpath="//a[@title=\"Log me out\"]")
	WebElement signout;
	@FindBy(xpath="//*[@id=\"center_column\"]/div[1]/ol/li")
	WebElement error;
	
	Logger log;
	public Account_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr,this);
	}
	
	public String getProfile() {
		
		String profile_name;
		try {
		WebDriverWait wt=new WebDriverWait(dr,10);
		wt.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"View my customer account\"]")));
		profile_name=profile.getText();
		}
		catch(Exception e) {
			profile_name= error.getText();
		}
		
		
		return profile_name;
	}
	
	public void signout() {
		try {
		signout.click();
		}
		catch(Exception e) {
			System.out.println("signin not clicked");
		}
		    System.out.println("signout clicked");
		
	}

}
