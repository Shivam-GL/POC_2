package Base_classes;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Home_page {
	WebDriver dr;
	
	
	@FindBy(xpath="//a[@title=\"Log in to your customer account\"]")
	WebElement signInLink;
	
	public Home_page(WebDriver dr) {
		this.dr=dr;
		 
		 PageFactory.initElements(dr, this);
	}

	public void clickSignin() {
		 signInLink.click();
	}
	public String getHomeTitle() {
		try {
		WebDriverWait wt=new WebDriverWait(dr,10);
		wt.until(ExpectedConditions.titleIs(dr.getTitle()));
		}
		catch(Exception e) {
			System.out.println("element not found");
		}
		String av=dr.getTitle();
		
		return av;
		
	}
	
	public String getSigninText() {
		String signin=signInLink.getText();
		
		return signin;
	}

}
