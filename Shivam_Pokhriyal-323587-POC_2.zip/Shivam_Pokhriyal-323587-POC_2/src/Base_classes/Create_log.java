package Base_classes;

import org.apache.log4j.Logger;

public class Create_log {
	
	
	public void writeLog(String name,String av,String ev,String result) {
		Logger log;
		log=Logger.getLogger("devpinoyLogger");
		log.info("====================================================================================");
		log.info("----------------------------------"+name+"------------------------------------------");
		log.info("====================================================================================");
		
		log.info("Expected Value : "+ev);
		log.info("Actual Value : "+av);
		log.info("Result : "+result);
		log.info("");
		
	}
}
